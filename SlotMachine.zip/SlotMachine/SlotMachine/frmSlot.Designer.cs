﻿
namespace SlotMachine
{
    partial class frmSlot
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSlot));
            this.lblSlot1 = new System.Windows.Forms.Label();
            this.tmrSlot1 = new System.Windows.Forms.Timer(this.components);
            this.btnLever = new System.Windows.Forms.Button();
            this.picPanda1 = new System.Windows.Forms.PictureBox();
            this.picPanda2 = new System.Windows.Forms.PictureBox();
            this.picPanda3 = new System.Windows.Forms.PictureBox();
            this.picPanda4 = new System.Windows.Forms.PictureBox();
            this.picPanda5 = new System.Windows.Forms.PictureBox();
            this.picPanda6 = new System.Windows.Forms.PictureBox();
            this.picPanda7 = new System.Windows.Forms.PictureBox();
            this.picSlot1 = new System.Windows.Forms.PictureBox();
            this.tmrSlot2 = new System.Windows.Forms.Timer(this.components);
            this.picSlot2 = new System.Windows.Forms.PictureBox();
            this.lblSlot2 = new System.Windows.Forms.Label();
            this.tmrSlot3 = new System.Windows.Forms.Timer(this.components);
            this.picSlot3 = new System.Windows.Forms.PictureBox();
            this.lblSlot3 = new System.Windows.Forms.Label();
            this.picBorder1 = new System.Windows.Forms.PictureBox();
            this.picBorder2 = new System.Windows.Forms.PictureBox();
            this.picBorder3 = new System.Windows.Forms.PictureBox();
            this.tmrWin = new System.Windows.Forms.Timer(this.components);
            this.lblBetDisplay = new System.Windows.Forms.Label();
            this.lblBet = new System.Windows.Forms.Label();
            this.lblWinningsDisplay = new System.Windows.Forms.Label();
            this.lblWinnings = new System.Windows.Forms.Label();
            this.lblCashDisplay = new System.Windows.Forms.Label();
            this.lblCash = new System.Windows.Forms.Label();
            this.lblSlotName = new System.Windows.Forms.Label();
            this.btnBet5 = new System.Windows.Forms.Button();
            this.btnBet1 = new System.Windows.Forms.Button();
            this.btnBetMax = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.lblPushButton = new System.Windows.Forms.Label();
            this.btnAdd1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.picPanda1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPanda2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPanda3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPanda4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPanda5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPanda6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPanda7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSlot1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSlot2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSlot3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBorder1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBorder2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBorder3)).BeginInit();
            this.SuspendLayout();
            // 
            // lblSlot1
            // 
            this.lblSlot1.AutoSize = true;
            this.lblSlot1.Location = new System.Drawing.Point(144, 98);
            this.lblSlot1.Name = "lblSlot1";
            this.lblSlot1.Size = new System.Drawing.Size(13, 13);
            this.lblSlot1.TabIndex = 0;
            this.lblSlot1.Text = "1";
            // 
            // tmrSlot1
            // 
            this.tmrSlot1.Tick += new System.EventHandler(this.tmrSlot1_Tick);
            // 
            // btnLever
            // 
            this.btnLever.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.btnLever.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnLever.BackgroundImage")));
            this.btnLever.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnLever.Font = new System.Drawing.Font("Monotype Corsiva", 36F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLever.Location = new System.Drawing.Point(789, 141);
            this.btnLever.Name = "btnLever";
            this.btnLever.Size = new System.Drawing.Size(144, 123);
            this.btnLever.TabIndex = 1;
            this.btnLever.UseVisualStyleBackColor = false;
            this.btnLever.Click += new System.EventHandler(this.btnLever_Click);
            // 
            // picPanda1
            // 
            this.picPanda1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picPanda1.BackgroundImage")));
            this.picPanda1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picPanda1.Location = new System.Drawing.Point(12, 448);
            this.picPanda1.Name = "picPanda1";
            this.picPanda1.Size = new System.Drawing.Size(100, 50);
            this.picPanda1.TabIndex = 2;
            this.picPanda1.TabStop = false;
            this.picPanda1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // picPanda2
            // 
            this.picPanda2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picPanda2.BackgroundImage")));
            this.picPanda2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picPanda2.Location = new System.Drawing.Point(147, 448);
            this.picPanda2.Name = "picPanda2";
            this.picPanda2.Size = new System.Drawing.Size(100, 50);
            this.picPanda2.TabIndex = 3;
            this.picPanda2.TabStop = false;
            // 
            // picPanda3
            // 
            this.picPanda3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picPanda3.BackgroundImage")));
            this.picPanda3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picPanda3.Location = new System.Drawing.Point(281, 448);
            this.picPanda3.Name = "picPanda3";
            this.picPanda3.Size = new System.Drawing.Size(100, 50);
            this.picPanda3.TabIndex = 4;
            this.picPanda3.TabStop = false;
            this.picPanda3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // picPanda4
            // 
            this.picPanda4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picPanda4.BackgroundImage")));
            this.picPanda4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picPanda4.Location = new System.Drawing.Point(413, 448);
            this.picPanda4.Name = "picPanda4";
            this.picPanda4.Size = new System.Drawing.Size(100, 50);
            this.picPanda4.TabIndex = 5;
            this.picPanda4.TabStop = false;
            // 
            // picPanda5
            // 
            this.picPanda5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picPanda5.BackgroundImage")));
            this.picPanda5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picPanda5.Location = new System.Drawing.Point(542, 448);
            this.picPanda5.Name = "picPanda5";
            this.picPanda5.Size = new System.Drawing.Size(100, 50);
            this.picPanda5.TabIndex = 6;
            this.picPanda5.TabStop = false;
            // 
            // picPanda6
            // 
            this.picPanda6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picPanda6.BackgroundImage")));
            this.picPanda6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picPanda6.Location = new System.Drawing.Point(671, 448);
            this.picPanda6.Name = "picPanda6";
            this.picPanda6.Size = new System.Drawing.Size(100, 50);
            this.picPanda6.TabIndex = 7;
            this.picPanda6.TabStop = false;
            // 
            // picPanda7
            // 
            this.picPanda7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picPanda7.BackgroundImage")));
            this.picPanda7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picPanda7.Location = new System.Drawing.Point(800, 448);
            this.picPanda7.Name = "picPanda7";
            this.picPanda7.Size = new System.Drawing.Size(100, 50);
            this.picPanda7.TabIndex = 8;
            this.picPanda7.TabStop = false;
            // 
            // picSlot1
            // 
            this.picSlot1.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.picSlot1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picSlot1.Location = new System.Drawing.Point(48, 141);
            this.picSlot1.Name = "picSlot1";
            this.picSlot1.Size = new System.Drawing.Size(190, 123);
            this.picSlot1.TabIndex = 9;
            this.picSlot1.TabStop = false;
            // 
            // tmrSlot2
            // 
            this.tmrSlot2.Tick += new System.EventHandler(this.tmrSlot2_Tick);
            // 
            // picSlot2
            // 
            this.picSlot2.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.picSlot2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picSlot2.Location = new System.Drawing.Point(286, 141);
            this.picSlot2.Name = "picSlot2";
            this.picSlot2.Size = new System.Drawing.Size(193, 123);
            this.picSlot2.TabIndex = 11;
            this.picSlot2.TabStop = false;
            // 
            // lblSlot2
            // 
            this.lblSlot2.AutoSize = true;
            this.lblSlot2.Location = new System.Drawing.Point(368, 98);
            this.lblSlot2.Name = "lblSlot2";
            this.lblSlot2.Size = new System.Drawing.Size(13, 13);
            this.lblSlot2.TabIndex = 10;
            this.lblSlot2.Text = "1";
            this.lblSlot2.Click += new System.EventHandler(this.lblSlot2_Click);
            // 
            // tmrSlot3
            // 
            this.tmrSlot3.Tick += new System.EventHandler(this.tmrSlot3_Tick);
            // 
            // picSlot3
            // 
            this.picSlot3.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.picSlot3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picSlot3.Location = new System.Drawing.Point(530, 141);
            this.picSlot3.Name = "picSlot3";
            this.picSlot3.Size = new System.Drawing.Size(180, 123);
            this.picSlot3.TabIndex = 13;
            this.picSlot3.TabStop = false;
            // 
            // lblSlot3
            // 
            this.lblSlot3.AutoSize = true;
            this.lblSlot3.Location = new System.Drawing.Point(608, 98);
            this.lblSlot3.Name = "lblSlot3";
            this.lblSlot3.Size = new System.Drawing.Size(13, 13);
            this.lblSlot3.TabIndex = 12;
            this.lblSlot3.Text = "1";
            this.lblSlot3.Click += new System.EventHandler(this.lblSlot3_Click);
            // 
            // picBorder1
            // 
            this.picBorder1.Location = new System.Drawing.Point(32, 125);
            this.picBorder1.Name = "picBorder1";
            this.picBorder1.Size = new System.Drawing.Size(223, 154);
            this.picBorder1.TabIndex = 14;
            this.picBorder1.TabStop = false;
            // 
            // picBorder2
            // 
            this.picBorder2.Location = new System.Drawing.Point(271, 125);
            this.picBorder2.Name = "picBorder2";
            this.picBorder2.Size = new System.Drawing.Size(224, 154);
            this.picBorder2.TabIndex = 15;
            this.picBorder2.TabStop = false;
            // 
            // picBorder3
            // 
            this.picBorder3.Location = new System.Drawing.Point(513, 125);
            this.picBorder3.Name = "picBorder3";
            this.picBorder3.Size = new System.Drawing.Size(213, 154);
            this.picBorder3.TabIndex = 16;
            this.picBorder3.TabStop = false;
            // 
            // tmrWin
            // 
            this.tmrWin.Tick += new System.EventHandler(this.timerWin_Tick);
            // 
            // lblBetDisplay
            // 
            this.lblBetDisplay.AutoSize = true;
            this.lblBetDisplay.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.lblBetDisplay.Font = new System.Drawing.Font("Monotype Corsiva", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBetDisplay.Location = new System.Drawing.Point(43, 313);
            this.lblBetDisplay.Name = "lblBetDisplay";
            this.lblBetDisplay.Size = new System.Drawing.Size(48, 25);
            this.lblBetDisplay.TabIndex = 17;
            this.lblBetDisplay.Text = "Bet:";
            // 
            // lblBet
            // 
            this.lblBet.AutoSize = true;
            this.lblBet.Font = new System.Drawing.Font("Algerian", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBet.Location = new System.Drawing.Point(148, 320);
            this.lblBet.Name = "lblBet";
            this.lblBet.Size = new System.Drawing.Size(68, 18);
            this.lblBet.TabIndex = 18;
            this.lblBet.Text = "label1";
            // 
            // lblWinningsDisplay
            // 
            this.lblWinningsDisplay.AutoSize = true;
            this.lblWinningsDisplay.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.lblWinningsDisplay.Font = new System.Drawing.Font("Monotype Corsiva", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWinningsDisplay.Location = new System.Drawing.Point(43, 349);
            this.lblWinningsDisplay.Name = "lblWinningsDisplay";
            this.lblWinningsDisplay.Size = new System.Drawing.Size(99, 25);
            this.lblWinningsDisplay.TabIndex = 19;
            this.lblWinningsDisplay.Text = "Winnings:";
            // 
            // lblWinnings
            // 
            this.lblWinnings.AutoSize = true;
            this.lblWinnings.Font = new System.Drawing.Font("Algerian", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWinnings.Location = new System.Drawing.Point(148, 356);
            this.lblWinnings.Name = "lblWinnings";
            this.lblWinnings.Size = new System.Drawing.Size(68, 18);
            this.lblWinnings.TabIndex = 20;
            this.lblWinnings.Text = "label1";
            this.lblWinnings.Click += new System.EventHandler(this.lblWinnings_Click);
            // 
            // lblCashDisplay
            // 
            this.lblCashDisplay.AutoSize = true;
            this.lblCashDisplay.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.lblCashDisplay.Font = new System.Drawing.Font("Monotype Corsiva", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCashDisplay.Location = new System.Drawing.Point(43, 390);
            this.lblCashDisplay.Name = "lblCashDisplay";
            this.lblCashDisplay.Size = new System.Drawing.Size(58, 25);
            this.lblCashDisplay.TabIndex = 21;
            this.lblCashDisplay.Text = "Cash:";
            this.lblCashDisplay.Click += new System.EventHandler(this.lblCashDisplay_Click);
            // 
            // lblCash
            // 
            this.lblCash.AutoSize = true;
            this.lblCash.Font = new System.Drawing.Font("Algerian", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCash.Location = new System.Drawing.Point(148, 395);
            this.lblCash.Name = "lblCash";
            this.lblCash.Size = new System.Drawing.Size(68, 18);
            this.lblCash.TabIndex = 22;
            this.lblCash.Text = "label1";
            // 
            // lblSlotName
            // 
            this.lblSlotName.AutoSize = true;
            this.lblSlotName.BackColor = System.Drawing.Color.FloralWhite;
            this.lblSlotName.Font = new System.Drawing.Font("Monotype Corsiva", 48F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSlotName.Location = new System.Drawing.Point(133, 9);
            this.lblSlotName.Name = "lblSlotName";
            this.lblSlotName.Size = new System.Drawing.Size(515, 79);
            this.lblSlotName.TabIndex = 23;
            this.lblSlotName.Text = "🐼 Slot Machine 🐼";
            this.lblSlotName.Click += new System.EventHandler(this.label1_Click);
            // 
            // btnBet5
            // 
            this.btnBet5.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.btnBet5.Font = new System.Drawing.Font("Algerian", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBet5.Location = new System.Drawing.Point(380, 340);
            this.btnBet5.Name = "btnBet5";
            this.btnBet5.Size = new System.Drawing.Size(99, 43);
            this.btnBet5.TabIndex = 24;
            this.btnBet5.Text = "Bet $5";
            this.btnBet5.UseVisualStyleBackColor = false;
            this.btnBet5.Click += new System.EventHandler(this.btnBet4_Click);
            // 
            // btnBet1
            // 
            this.btnBet1.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.btnBet1.Font = new System.Drawing.Font("Algerian", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBet1.Location = new System.Drawing.Point(258, 340);
            this.btnBet1.Name = "btnBet1";
            this.btnBet1.Size = new System.Drawing.Size(95, 43);
            this.btnBet1.TabIndex = 25;
            this.btnBet1.Text = "Bet $1";
            this.btnBet1.UseVisualStyleBackColor = false;
            this.btnBet1.Click += new System.EventHandler(this.btnBet1_Click);
            // 
            // btnBetMax
            // 
            this.btnBetMax.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.btnBetMax.Font = new System.Drawing.Font("Algerian", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBetMax.Location = new System.Drawing.Point(513, 340);
            this.btnBetMax.Name = "btnBetMax";
            this.btnBetMax.Size = new System.Drawing.Size(116, 43);
            this.btnBetMax.TabIndex = 26;
            this.btnBetMax.Text = "Bet Max";
            this.btnBetMax.UseVisualStyleBackColor = false;
            this.btnBetMax.Click += new System.EventHandler(this.btnBetMax_Click);
            // 
            // btnReset
            // 
            this.btnReset.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.btnReset.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnReset.Font = new System.Drawing.Font("Monotype Corsiva", 27.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReset.Location = new System.Drawing.Point(789, 331);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(144, 54);
            this.btnReset.TabIndex = 27;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = false;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // lblPushButton
            // 
            this.lblPushButton.AutoSize = true;
            this.lblPushButton.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.lblPushButton.Font = new System.Drawing.Font("Monotype Corsiva", 26.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPushButton.Location = new System.Drawing.Point(788, 78);
            this.lblPushButton.Name = "lblPushButton";
            this.lblPushButton.Size = new System.Drawing.Size(147, 43);
            this.lblPushButton.TabIndex = 40;
            this.lblPushButton.Text = "Push Me!";
            // 
            // btnAdd1
            // 
            this.btnAdd1.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.btnAdd1.Font = new System.Drawing.Font("Algerian", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd1.Location = new System.Drawing.Point(661, 340);
            this.btnAdd1.Name = "btnAdd1";
            this.btnAdd1.Size = new System.Drawing.Size(98, 43);
            this.btnAdd1.TabIndex = 41;
            this.btnAdd1.Text = "Add $1";
            this.btnAdd1.UseVisualStyleBackColor = false;
            this.btnAdd1.Click += new System.EventHandler(this.button1_Click);
            // 
            // frmSlot
            // 
            this.AcceptButton = this.btnLever;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.CancelButton = this.btnReset;
            this.ClientSize = new System.Drawing.Size(970, 570);
            this.Controls.Add(this.btnAdd1);
            this.Controls.Add(this.lblPushButton);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnBetMax);
            this.Controls.Add(this.btnBet1);
            this.Controls.Add(this.btnBet5);
            this.Controls.Add(this.lblSlotName);
            this.Controls.Add(this.lblCash);
            this.Controls.Add(this.lblCashDisplay);
            this.Controls.Add(this.lblWinnings);
            this.Controls.Add(this.lblWinningsDisplay);
            this.Controls.Add(this.lblBet);
            this.Controls.Add(this.lblBetDisplay);
            this.Controls.Add(this.picSlot3);
            this.Controls.Add(this.lblSlot3);
            this.Controls.Add(this.picSlot2);
            this.Controls.Add(this.lblSlot2);
            this.Controls.Add(this.picSlot1);
            this.Controls.Add(this.picPanda7);
            this.Controls.Add(this.picPanda6);
            this.Controls.Add(this.picPanda5);
            this.Controls.Add(this.picPanda4);
            this.Controls.Add(this.picPanda3);
            this.Controls.Add(this.picPanda2);
            this.Controls.Add(this.picPanda1);
            this.Controls.Add(this.btnLever);
            this.Controls.Add(this.lblSlot1);
            this.Controls.Add(this.picBorder1);
            this.Controls.Add(this.picBorder2);
            this.Controls.Add(this.picBorder3);
            this.Name = "frmSlot";
            this.Text = "THE Panda Slot";
            this.Load += new System.EventHandler(this.frmSlot_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picPanda1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPanda2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPanda3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPanda4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPanda5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPanda6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPanda7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSlot1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSlot2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSlot3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBorder1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBorder2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBorder3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblSlot1;
        private System.Windows.Forms.Timer tmrSlot1;
        private System.Windows.Forms.Button btnLever;
        private System.Windows.Forms.PictureBox picPanda1;
        private System.Windows.Forms.PictureBox picPanda2;
        private System.Windows.Forms.PictureBox picPanda3;
        private System.Windows.Forms.PictureBox picPanda4;
        private System.Windows.Forms.PictureBox picPanda5;
        private System.Windows.Forms.PictureBox picPanda6;
        private System.Windows.Forms.PictureBox picPanda7;
        private System.Windows.Forms.PictureBox picSlot1;
        private System.Windows.Forms.Timer tmrSlot2;
        private System.Windows.Forms.PictureBox picSlot2;
        private System.Windows.Forms.Label lblSlot2;
        private System.Windows.Forms.Timer tmrSlot3;
        private System.Windows.Forms.PictureBox picSlot3;
        private System.Windows.Forms.Label lblSlot3;
        private System.Windows.Forms.PictureBox picBorder1;
        private System.Windows.Forms.PictureBox picBorder2;
        private System.Windows.Forms.PictureBox picBorder3;
        private System.Windows.Forms.Timer tmrWin;
        private System.Windows.Forms.Label lblBetDisplay;
        private System.Windows.Forms.Label lblBet;
        private System.Windows.Forms.Label lblWinningsDisplay;
        private System.Windows.Forms.Label lblWinnings;
        private System.Windows.Forms.Label lblCashDisplay;
        private System.Windows.Forms.Label lblCash;
        private System.Windows.Forms.Label lblSlotName;
        private System.Windows.Forms.Button btnBet5;
        private System.Windows.Forms.Button btnBet1;
        private System.Windows.Forms.Button btnBetMax;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Label lblPushButton;
        private System.Windows.Forms.Button btnAdd1;
    }
}

