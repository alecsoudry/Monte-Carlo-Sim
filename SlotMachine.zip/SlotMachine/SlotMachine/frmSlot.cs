﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SlotMachine
{
    public partial class frmSlot : Form
    {
        //Keeps all the borders from going off
        private bool myblnBorder1 = false;
        private bool myblnBorder2 = false;
        private bool myblnBorder3 = false;

        //These will handle money
        private decimal mydecBet = 1;
        private decimal mydecWinnings = 0;
        private decimal mydecCash = 10;
        
        public frmSlot()
        {
            InitializeComponent();
        }
        //Changes the picturesin slot 1 until the timer above stops
        private void tmrSlot1_Tick(object sender, EventArgs e)
        {
            ChangePicture(lblSlot1, picSlot1);
            if (Stop())
            {
                tmrSlot1.Enabled = false;
            }
        }
        private void ChangePicture(Label lbl, PictureBox pic) {
            int intNumber = int.Parse(lbl.Text);
            intNumber++; //This will add 1 to intNumber
            //Make sure the number is not bigger than the number of pictures
            if (intNumber>7)
            {
                intNumber = 1;
            }
            //This is making the pictures tick as the numbers tick
            lbl.Text = intNumber.ToString();
            Image picPanda = ((PictureBox)this.Controls.Find("picPanda" + intNumber.ToString(), true)[0]).BackgroundImage;
            pic.BackgroundImage = picPanda;
        }

        private void btnLever_Click(object sender, EventArgs e)
        {
            //This is when the casino gets my cash after the lever gets pulled and all buttons become disabled
            mydecCash -= mydecBet;
            btnLever.Enabled = false;
            tmrSlot1.Enabled = true;
            tmrSlot2.Enabled = true;
            tmrSlot3.Enabled = true;
            btnBet1.Enabled = false;
            btnBet5.Enabled = false;
            btnBetMax.Enabled = false;
            btnReset.Enabled = false;
            btnAdd1.Enabled = false;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            //Went click happy
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            //Went click happy
        }
        //Shows the money avaliable
        private void frmSlot_Load(object sender, EventArgs e)
        {
            ShowMeDaMoney();
        }

        private void lblSlot2_Click(object sender, EventArgs e)
        {
            // Went click happy
        }
        //Stops the second picture when the timer above stops and after the first timer
        private void tmrSlot2_Tick(object sender, EventArgs e)
        {
            ChangePicture(lblSlot2, picSlot2);
            if (!tmrSlot1.Enabled && Stop())
            {
                tmrSlot2.Enabled = false;
            }
        }
        //Stops the third picture when its corresponding timer finishes, after timer 2 is done
        private void tmrSlot3_Tick(object sender, EventArgs e)
        {
            ChangePicture(lblSlot3, picSlot3);
            if (!tmrSlot2.Enabled && Stop())
            {
                //This re-enables the buttons so the user can play again
                tmrSlot3.Enabled = false;
                btnLever.Enabled = true;
                btnBet1.Enabled = true;
                btnBet5.Enabled = true;
                btnBetMax.Enabled = true;
                btnReset.Enabled = true;
                btnAdd1.Enabled = true;
                Win();
            }
        }
            Random rndStop = new Random();     
        private bool Stop()
        {
            //This will return true if the random number generator says to

            return rndStop.Next(0, 10) == 7;
        }
        private void Win()
        {
            //This will check if I won or not
            mydecWinnings = 0;
            //we need to set these to false because none of the windows are winners by default
            myblnBorder1 = false;
            myblnBorder2 = false;
            myblnBorder3 = false;
            if (lblSlot1.Text == lblSlot2.Text && lblSlot1.Text == lblSlot3.Text)
            {
                //If this is true, BIG WINNER!!!
                myblnBorder1 = true;
                myblnBorder2 = true;
                myblnBorder3 = true;
                mydecWinnings = mydecBet * 10;
                MessageBox.Show("You are on the verge of bankrupting my casino, buy something nice with my money!", "Congratulations!");
            }
            else if (lblSlot1.Text == lblSlot2.Text)
            {
                //If this is true, small Winner
                myblnBorder1 = true;
                myblnBorder2 = true;
                mydecWinnings = mydecBet;
            }
            else if (lblSlot1.Text == lblSlot3.Text)
            {
                //If this is true, Small Winner
                myblnBorder1 = true;
                myblnBorder3 = true;
                mydecWinnings = mydecBet;
            }
            else if (lblSlot2.Text == lblSlot3.Text)
            {
                //If this is true, Small Winner
                myblnBorder2 = true;
                myblnBorder3 = true;
                mydecWinnings = mydecBet;
            }
            else
            {
                MessageBox.Show("You won nothing :)", "My sincerest apologies");
            }
            //sets amount of cash to include any money won
            mydecCash = mydecCash + mydecWinnings;
            ShowMeDaMoney();
            tmrWin.Enabled = true;
        }

        private void lblSlot3_Click(object sender, EventArgs e)
        {
            //Went click happy
        }

        private void timerWin_Tick(object sender, EventArgs e)
        {
            //This will change the back color of the winning borders
            if (picBorder1.BackColor == Color.Violet)
            {
                picBorder1.BackColor = Color.LightGreen;
            }
            else if (picBorder1.BackColor == Color.LightGreen)
            {
                picBorder1.BackColor = Color.LightBlue;
            }
            else
            {
                picBorder1.BackColor = Color.Violet;
            }
            picBorder2.BackColor = picBorder1.BackColor;
            picBorder3.BackColor = picBorder1.BackColor;
            //This turns off the winning border colors
            if (Stop())
            {
                tmrWin.Enabled = false;
                myblnBorder1 = false;
                myblnBorder2 = false;
                myblnBorder3 = false;
            }

            //This will show the right borders
            picBorder1.Visible = myblnBorder1;
            picBorder2.Visible = myblnBorder2;
            picBorder3.Visible = myblnBorder3;
        }

        private void lblCashDisplay_Click(object sender, EventArgs e)
        {
            //Went click happy
        }

        private void lblWinnings_Click(object sender, EventArgs e)
        {
            //Went click happy
        }
        private void ShowMeDaMoney()
        {
            //This displays a message when the player is out of money (cash is less than or equal to 0
            if (mydecCash <=0)
            {
                MessageBox.Show("Since I am known as the most generous man on this side of the Mississippi, I will 'lend' you more money.","You are out of money!");
                //When the player runs out of money, we want the machine to reset
                ResetEverything();
            }

            if (mydecBet>mydecCash)
            {
                //This makes sure the player can't bet more than the amount of cash they have
                mydecBet = mydecCash;
            }
            //This makes Bet 5 disabled if you have less than $5
            if (mydecCash < 5)
            {
                btnBet5.Enabled = false;
            }
            

            lblBet.Text = mydecBet.ToString("C");
            lblWinnings.Text = mydecWinnings.ToString("C");
            lblCash.Text = mydecCash.ToString("C");
            //The "C" formats the string into currency
        }
        private void ResetEverything()
        {
            //This resets the slot machine
            mydecBet = 1;
            mydecCash = 10;
            mydecWinnings = 0;
            ShowMeDaMoney();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            //Went click happy
        }

        private void btnBet4_Click(object sender, EventArgs e)
        {
            //This changes the bet to $5 and shows us
            mydecBet = 5;
            ShowMeDaMoney();
        }

        private void btnBet1_Click(object sender, EventArgs e)
        {
            //This changes the bet to $1 and shows us
            mydecBet = 1;
            ShowMeDaMoney();
        }

        private void btnBetMax_Click(object sender, EventArgs e)
        {
            //This changes the bet to all the cash we have and shows us
            mydecBet = mydecCash;
            ShowMeDaMoney();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            //This resets all cash and winnings
            ResetEverything();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //This adds $1 to my current bet and shows us
            mydecBet = mydecBet +1;
            ShowMeDaMoney();
        }
    }
}
